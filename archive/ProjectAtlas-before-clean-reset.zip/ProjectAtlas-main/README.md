# Project Atlas Research Package v0.1

Adds the first public Atlas Papers research section to the existing static GitHub Pages site.

## Included
- `research/index.html` — Atlas Papers landing page
- `research/papers/atlas-paper-001.html` — first working research proposal
- `research/assets/research.css` — responsive design
- `Install_Research_Package.command` — macOS installer

## Before publishing
1. Replace `research@projectatlas.example` with the real review email or form URL.
2. Add a navigation link from the main `index.html` to `research/`.
3. Review the comparison table. It is intentionally labelled as a hypothesis.
4. Test locally with `python3 -m http.server 8080`, then open `http://localhost:8080/research/`.

The package leads with Project Atlas and does not lock in the unresolved company name.

Suggested commit: `Publish Atlas Papers and Paper 001 working proposal`
Suggested URL: `https://mtsalisbury.github.io/ProjectAtlas/research/`
