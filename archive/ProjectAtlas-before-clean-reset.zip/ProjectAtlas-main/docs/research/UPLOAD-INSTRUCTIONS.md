# Upload instructions

Replace:

docs/research/index.html

with the supplied:

index.html

Then commit and push.

Suggested commit message:

Update Project Atlas research portal

This page is standalone and includes its own CSS. It links back to the homepage with `../` and to both paper files under `docs/research/papers/`.
