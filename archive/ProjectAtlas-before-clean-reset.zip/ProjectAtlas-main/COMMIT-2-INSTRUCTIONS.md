# Commit 2 Instructions

Copy the following items into the root of your local `ProjectAtlas` folder:

- `index.html`
- `style.css`
- `survey-setup.html`
- `assets/atlas-mark.svg`

Allow the new files to replace the existing placeholder versions.

Then open GitHub Desktop.

1. Review the changed files.
2. Use the commit summary:

   `Build Project Atlas public landing page`

3. Click **Commit to main**.
4. Click **Push origin**.

The survey button currently opens a local placeholder page. The next small update will connect it to the live survey URL.
