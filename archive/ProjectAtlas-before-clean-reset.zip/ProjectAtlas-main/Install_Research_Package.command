#!/bin/bash
set -e
D="$(cd "$(dirname "$0")" && pwd)"
R=$(osascript -e 'POSIX path of (choose folder with prompt "Select your local ProjectAtlas Git repository")')
R="${R%/}"
[ -d "$R/.git" ] || { osascript -e 'display alert "The selected folder is not a Git repository." as critical'; exit 1; }
mkdir -p "$R/research"
rsync -av "$D/research/" "$R/research/"
cd "$R"
git add research
git commit -m "Publish Atlas Papers and Paper 001 working proposal" || true
if osascript -e 'display dialog "Research package installed. Push the commit to GitHub now?" buttons {"Not Now","Push"} default button "Push"' | grep -q Push; then git push origin main; fi
osascript -e 'display dialog "Atlas Papers research package installation is complete." buttons {"OK"}'
