PROJECT ATLAS HOMEPAGE v1

Files included:
- website/index.html
- website/style.css

Installation:
1. Back up your existing website/index.html and website/style.css.
2. Copy these two replacement files into the website folder.
3. Confirm the existing folders remain in place:
   website/research/
   website/assets/
4. Commit and push through GitHub Desktop.
5. Wait for the Deploy Project Atlas workflow to complete.

Expected links:
- /ProjectAtlas/
- /ProjectAtlas/research/
- /ProjectAtlas/research/papers/atlas-paper-001.html
- /ProjectAtlas/survey-setup.html
